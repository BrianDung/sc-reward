import { deployContract, Fixture } from "ethereum-waffle";
import web3 from "web3";
import {
  MintableToken,
  RewardDistributor,
} from "../../typechain";
import * as MintableTokenJSON from "../../artifacts/contracts/mocks/MintableToken.sol/MintableToken.json";
import * as RewardDisTributorJSON from "../../artifacts/contracts/RewardDistributor.sol/RewardDistributor.json";
interface IFixture {
  mintableToken: MintableToken;
  distributor: RewardDistributor;
}

const { toWei } = web3.utils;

export const fixture: Fixture<IFixture | any> = async ([wallet], _) => {

  const mintableToken = (await deployContract(
    wallet as any,
    MintableTokenJSON,
  )) as unknown as MintableToken;


  const distributor = (await deployContract(
    wallet as any,
    RewardDisTributorJSON,
    [wallet.address]
  )) as unknown as RewardDistributor;

  await mintableToken.initialize("Mintable Token", "MAT", toWei("100000000000000"));


  return {
    mintableToken,
    distributor,
  };
};