import web3 from "web3";
import { Wallet } from "ethers";
import { ethers, waffle } from "hardhat";
import { fixture } from "./utils/fixture";
import { expect } from "chai";
import { MintableToken } from "../typechain/MintableToken";
import { RewardDistributor } from "../typechain";
import { MOD_ROLE, ADMIN_ROLE } from "./utils/constant";
const { toWei } = web3.utils;


describe("reward distributor", function () {
  let signer: Wallet;
  let wallets: Wallet[];
  let account1: Wallet;
  let loadFixture: ReturnType<typeof waffle.createFixtureLoader>;
  let mintableToken: MintableToken;
  let distributor: RewardDistributor;

  async function sign(token: String, amount: String, address: String) {
    let message = ethers.utils.solidityKeccak256(
      ["uint256", "address", "address"],
      [amount, address, token]
    );
    let messageStringBytes = ethers.utils.arrayify(message)
    return await signer.signMessage(messageStringBytes);
  }



  before("create fixture loader", async () => {
    wallets = await (ethers as any).getSigners();
    signer = wallets[0];
    account1 = wallets[1];
  });

  beforeEach(async () => {
    loadFixture = waffle.createFixtureLoader(wallets as any);
    ({ mintableToken, distributor } = await loadFixture(fixture));

    await mintableToken.transfer(account1.address, toWei("1000"));
    await mintableToken.transfer(distributor.address, toWei("1000"));

  });

  it(" claim reward", async () => {
    const flatSig = await sign(mintableToken.address, toWei("1"), account1.address);


    await expect(
      distributor.connect(account1).claimRewards(mintableToken.address, toWei("1"), flatSig)
    ).to.emit(distributor, "UserClaimed")
      .withArgs(account1.address, toWei("1"));


  });

  it("admin withdraw", async () => {
    const beforeBalance = await mintableToken.balanceOf(signer.address);

    await expect(
      distributor.adminWithdraw(mintableToken.address, toWei("1"))
    ).to.not.be.reverted;

    const afterBalance = await mintableToken.balanceOf(signer.address);

    expect(afterBalance.sub(beforeBalance).toString()).to.equal(toWei("1"));

  })
});
